import os
import base64
import requests

# ================= CẤU HÌNH THÔNG TIN CỦA BẠN VÀO ĐÂY =================
GITHUB_TOKEN = "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"  # Mã ghp_... lấy từ GitHub
REPO_OWNER = "Nhanhnaoo"  # Ví dụ: nguyenvana
REPO_NAME = "Nhanhnao"  # Tên kho lưu trữ trên GitHub
# =====================================================================
# Chú ý: Đổi tên file trong list này trùng với tên file python thực tế của bạn (git-upload.py hoặc git_upload.py)
IGNORE_LIST = [
    "node_modules", ".git", "dist", ".astro", ".wrangler", 
    ".mf", ".env", ".dev.vars", "git-upload.js", "git-upload.py", "git_upload.py"
]

def get_all_files(base_dir):
    valid_files = []
    for root, dirs, files in os.walk(base_dir):
        dirs[:] = [d for d in dirs if d not in IGNORE_LIST]
        for file in files:
            if file in IGNORE_LIST: continue
            full_path = os.path.join(root, file)
            rel_path = os.path.relpath(full_path, base_dir).replace("\\", "/")
            valid_files.append({"local_path": full_path, "git_path": rel_path})
    return valid_files

def get_github_repo_tree(headers):
    """Lấy danh sách tất cả file hiện tại đang có trên GitHub để xử lý SHA và xóa file rác"""
    tree_url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/branches/main"
    res = requests.get(tree_url, headers=headers)
    if res.status_code != 200:
        return {}
    
    sha_latest_commit = res.json()["commit"]["sha"]
    files_url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/git/trees/{sha_latest_commit}?recursive=1"
    res_tree = requests.get(files_url, headers=headers)
    
    if res_tree.status_code == 200:
        # Trả về dictionary dạng: {"path/file.txt": "sha_cua_file"}
        return {item["path"]: item["sha"] for item in res_tree.json().get("tree", []) if item["type"] == "blob"}
    return {}

def upload_to_github():
    print("⏳ Bước 1: Đang quét toàn bộ file local trong dự án...")
    local_files = get_all_files(os.getcwd())
    local_paths = [f["git_path"] for f in local_files]
    print(f"=> Tìm thấy {len(local_files)} file hợp lệ dưới máy.")

    headers = {
        "Authorization": f"Bearer {GITHUB_TOKEN}",
        "Content-Type": "application/json",
        "User-Agent": "Python-Upload-Script",
        "Accept": "application/vnd.github+json"
    }
    
    # Lấy cấu trúc file hiện tại trên GitHub
    print("\n🔍 Bước 2: Đang quét cấu trúc file hiện tại trên mạng GitHub...")
    github_files = get_github_repo_tree(headers)
    print(f"=> Trên GitHub đang có {len(github_files)} file.")

    # 1. TIẾN HÀNH XÓA CÁC FILE RÁC TRÊN GITHUB (File có trên mạng nhưng không có ở máy máy local)
    print("\n🗑️  Bước 3: Đang kiểm tra và dọn dẹp file rác cũ trên GitHub...")
    base_api_url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/contents/"
    
    for git_path, sha in github_files.items():
        if git_path not in local_paths and git_path not in IGNORE_LIST:
            del_payload = {
                "message": f"Dọn dẹp file cũ: Đã xóa {git_path}",
                "sha": sha
            }
            requests.delete(base_api_url + git_path, headers=headers, json=del_payload)
            print(f"🗑️  Đã xóa file rác: {git_path}")

    # 2. ĐẨY FILE MỚI HOẶC CẬP NHẬT FILE CŨ ĐÚNG SHA
    print("\n🚀 Bước 4: Đang đồng bộ toàn bộ file mới lên GitHub...")
    for file in local_files:
        file_url = base_api_url + file["git_path"]
        try:
            with open(file["local_path"], "rb") as f:
                content_base64 = base64.b64encode(f.read()).decode("utf-8")

            payload = {
                "message": f"Đồng bộ chuẩn: {file['git_path']}",
                "content": content_base64
            }
            
            # Nếu file này đã có trên GitHub, bắt buộc phải đính kèm SHA cũ để ghi đè thành công
            if file["git_path"] in github_files:
                payload["sha"] = github_files[file["git_path"]]

            res = requests.put(file_url, headers=headers, json=payload, timeout=15)

            if res.status_code in [200, 201]:
                print(f"✅ Đã đồng bộ: {file['git_path']}")
            else:
                print(f"❌ Thất bại {file['git_path']}: {res.json().get('message')}")

        except Exception as e:
            print(f"❌ Lỗi kết nối file {file['git_path']}: {str(e)}")

    print("\n🎉 HOÀN THÀNH ĐỒNG BỘ HOÀN HẢO!")
    print("⚡ Code sạch đã lên mây. Hãy kiểm tra Cloudflare Pages để xem kết quả!")

if __name__ == "__main__":
    upload_to_github()